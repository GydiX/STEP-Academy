﻿using System.Text;

namespace _03_http
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // http = 80
            // https = 443


            // HttpClient


            // get запит на https://google.com
            //HttpClient client = new HttpClient();

            //var response = await client.GetAsync("https://google.com");

            //if(response.IsSuccessStatusCode)
            //{
            //    byte[] content = await response.Content.ReadAsByteArrayAsync();
            //    File.WriteAllBytes("index.html", content);
            //}
            //else
            //{
            //    Console.WriteLine(response.StatusCode);
            //}




            // закачка файлу

            //HttpClient client = new HttpClient();
            //var response = await client.GetAsync("https://w7.pngwing.com/pngs/895/199/png-transparent-spider-man-heroes-download-with-transparent-background-free-thumbnail.png");

            //if(response.IsSuccessStatusCode)
            //{
            //    var stream = await response.Content.ReadAsStreamAsync();

            //    var fileStream = File.Create("image.png");
            //    stream.CopyTo(fileStream);
            //    fileStream.Dispose();
            //    stream.Dispose();
            //}

            //Console.ReadLine();




            // робота з JSON

            await WeatherClient.GetWeatherAsync2();
        }
    }
}
