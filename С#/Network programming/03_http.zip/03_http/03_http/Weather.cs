﻿using System.Net.Http.Json;

namespace _03_http
{
    public static class WeatherClient
    {
        public async static Task GetWeatherAsync()
        {
            string url = "https://api.openweathermap.org/data/2.5/weather?q=Rivne&appid=bf89f3f10b52303587e748f50178cba8&units=metric&lang=ua";

            var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                //string json = await response.Content.ReadAsStringAsync();

                //WeatherModel2? model = JsonSerializer.Deserialize<WeatherModel2>(json);

                //if (model != null)
                //{
                //    Console.WriteLine(model.main.temp);
                //}


                WeatherModel2? model = await response.Content.ReadFromJsonAsync<WeatherModel2>();

                if (model != null)
                {
                    Console.WriteLine(model.main.temp);
                }
            }
        }

        public async static Task GetWeatherAsync2()
        {
            string url = "https://api.openweathermap.org/data/2.5/weather?q=Rivne&appid=bf89f3f10b52303587e748f50178cba8&units=metric&lang=ua";

            var client = new HttpClient();
            WeatherModel2? model = await client.GetFromJsonAsync<WeatherModel2>(url);
            Console.WriteLine(model.weather[0].description);
            
        }
    }
}
